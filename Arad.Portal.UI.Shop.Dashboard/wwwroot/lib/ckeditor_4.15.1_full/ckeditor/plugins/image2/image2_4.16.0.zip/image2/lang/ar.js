/*
Copyright (c) 2003-2021, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'image2', 'ar', {
	alt: 'عنوان الصورة',
	btnUpload: 'أرسلها للخادم',
	captioned: 'صورة ذات اسم',
	captionPlaceholder: 'تسمية',
	infoTab: 'معلومات الصورة',
	lockRatio: 'تناسق الحجم',
	menu: 'خصائص الصورة',
	pathName: 'صورة',
	pathNameCaption: 'تسمية',
	resetSize: 'إستعادة الحجم الأصلي',
	resizer: 'انقر ثم اسحب للتحجيم',
	title: 'خصائص الصورة',
	uploadTab: 'رفع',
	urlMissing: 'عنوان مصدر الصورة مفقود',
	altMissing: 'Alternative text is missing.' // MISSING
} );
